# Career Copilot Chrome Extension

Multi-user safe bridge: your LinkedIn/browser session stays local. The extension POSTs extracts to the Career Copilot API with your bearer token.

## Install

1. `chrome://extensions` → Developer mode → **Load unpacked** → this folder  
2. In the app **LinkedIn Coach**, copy API URL + token into the popup → Save  

For production API hosts, add the origin to `manifest.json` → `host_permissions`.

## Features

| Feature | How |
|---------|-----|
| **Job Aggregator** | On any job page → **Import job from this page** |
| **Smart Networking** | Enter company → **Suggest connections**; or import people from LinkedIn search |
| **Networking Agent** | **Send next agent action** opens profile + fills draft; **Process due** schedules follow-ups/nudges |
| **Conversation Assistant** | On LinkedIn Messaging → **Draft reply in my voice** (fills compose) |
| **Resume Builder** | Opens app Resume Versions |
| **Interview Prep** | Opens Application Tracker (interview packs) |
| **Job Health Analytics** | Compact 360° summary from API |

## Safety

The agent **drafts and schedules**; you confirm Send on LinkedIn, then **Mark sent** in the app so follow-ups continue. No LinkedIn password is stored on the server.
