/**
 * LinkedIn page helpers + generic job extract (injected on demand for any site).
 */

function cleanText(value) {
  return (value || "").replace(/\s+/g, " ").trim();
}

function absoluteLinkedInUrl(href) {
  if (!href) return null;
  try {
    const url = new URL(href, "https://www.linkedin.com");
    if (!url.hostname.includes("linkedin.com")) return null;
    if (!url.pathname.includes("/in/")) return null;
    url.search = "";
    url.hash = "";
    return url.toString().replace(/\/$/, "");
  } catch {
    return null;
  }
}

function extractProfile() {
  const main =
    document.querySelector("main") ||
    document.querySelector(".scaffold-layout__main") ||
    document.body;

  const name =
    cleanText(
      document.querySelector("h1.text-heading-xlarge")?.textContent ||
        document.querySelector(".pv-text-details__left-panel h1")?.textContent ||
        document.querySelector("h1")?.textContent,
    ) || "";

  const headline =
    cleanText(
      document.querySelector(".text-body-medium.break-words")?.textContent ||
        document.querySelector(".pv-text-details__left-panel .text-body-medium")?.textContent,
    ) || "";

  const about =
    cleanText(
      document.querySelector("#about ~ .display-flex .inline-show-more-text")?.textContent ||
        document.querySelector("#about")?.closest("section")?.textContent,
    ) || "";

  const experience =
    cleanText(document.querySelector("#experience")?.closest("section")?.textContent) || "";

  const education =
    cleanText(document.querySelector("#education")?.closest("section")?.textContent) || "";

  const skills =
    cleanText(document.querySelector("#skills")?.closest("section")?.textContent) || "";

  const parts = [
    name && `Name: ${name}`,
    headline && `Headline: ${headline}`,
    `Profile URL: ${window.location.href.split("?")[0]}`,
    about && `About:\n${about.slice(0, 4000)}`,
    experience && `Experience:\n${experience.slice(0, 8000)}`,
    education && `Education:\n${education.slice(0, 3000)}`,
    skills && `Skills:\n${skills.slice(0, 3000)}`,
  ].filter(Boolean);

  if (parts.join("\n").length < 120) {
    parts.push(`Page text:\n${cleanText(main.innerText).slice(0, 15000)}`);
  }

  return {
    type: "profile",
    profile_text: parts.join("\n\n"),
    page_url: window.location.href,
  };
}

function extractPeople() {
  const seen = new Map();
  const anchors = document.querySelectorAll('a[href*="/in/"]');

  for (const anchor of anchors) {
    const linkedin_url = absoluteLinkedInUrl(anchor.getAttribute("href"));
    if (!linkedin_url) continue;

    const card =
      anchor.closest("li") ||
      anchor.closest(".reusable-search__result-container") ||
      anchor.closest(".entity-result") ||
      anchor.closest("div[data-chameleon-result-urn]") ||
      anchor.parentElement;

    let person_name = cleanText(anchor.textContent);
    if (!person_name || person_name.length < 2 || person_name.toLowerCase() === "linkedin") {
      person_name = cleanText(
        card?.querySelector('[dir="ltr"]')?.textContent ||
          card?.querySelector("span[aria-hidden='true']")?.textContent,
      );
    }
    if (!person_name || person_name.length < 2) continue;

    const headline = cleanText(
      card?.querySelector(".entity-result__primary-subtitle")?.textContent ||
        card?.querySelector(".entity-result__summary")?.textContent ||
        card?.querySelector(".t-14.t-black.t-normal")?.textContent,
    );

    if (!seen.has(linkedin_url)) {
      seen.set(linkedin_url, {
        person_name: person_name.slice(0, 200),
        linkedin_url,
        headline: headline ? headline.slice(0, 500) : null,
      });
    }
  }

  return {
    type: "people",
    contacts: Array.from(seen.values()).slice(0, 40),
    page_url: window.location.href,
    company_guess: guessCompanyFromPage(),
  };
}

function guessCompanyFromPage() {
  const path = window.location.pathname;
  const companyMatch = path.match(/\/company\/([^/]+)/);
  if (companyMatch) {
    return decodeURIComponent(companyMatch[1]).replace(/-/g, " ");
  }
  const title = cleanText(document.title);
  if (title.includes("|")) {
    return title.split("|")[0].trim().slice(0, 100) || null;
  }
  return null;
}

function extractMessagingThread() {
  const nodes = document.querySelectorAll(
    ".msg-s-event-listitem__body, .msg-s-message-list__event, .msg-s-event-listitem",
  );
  const lines = [];
  for (const node of nodes) {
    const t = cleanText(node.innerText);
    if (t && t.length > 1) lines.push(t);
  }
  if (lines.length < 1) {
    const fallback = cleanText(
      document.querySelector(".msg-s-message-list")?.innerText ||
        document.querySelector("[data-test-conversation]")?.innerText ||
        "",
    );
    if (fallback) lines.push(fallback.slice(0, 6000));
  }
  return {
    type: "thread",
    thread_text: lines.slice(-40).join("\n\n").slice(0, 10000),
    page_url: window.location.href,
  };
}

function extractJobFromPage() {
  const ogTitle =
    document.querySelector('meta[property="og:title"]')?.getAttribute("content") || "";
  const h1 = cleanText(document.querySelector("h1")?.textContent);
  const title =
    cleanText(ogTitle) ||
    h1 ||
    cleanText(document.title).split("|")[0].split(" - ")[0].slice(0, 300);

  let company =
    cleanText(
      document.querySelector('[data-company-name]')?.textContent ||
        document.querySelector(".job-details-jobs-unified-top-card__company-name")?.textContent ||
        document.querySelector('a[href*="/company/"]')?.textContent,
    ) || "";

  if (!company) {
    const host = location.hostname.replace(/^www\./, "");
    company = host.split(".")[0] || "Unknown";
    company = company.charAt(0).toUpperCase() + company.slice(1);
  }

  const description = cleanText(
    document.querySelector("#job-details")?.innerText ||
      document.querySelector(".jobs-description")?.innerText ||
      document.querySelector("article")?.innerText ||
      document.querySelector("main")?.innerText ||
      document.body.innerText,
  ).slice(0, 20000);

  const locationText = cleanText(
    document.querySelector(".job-details-jobs-unified-top-card__bullet")?.textContent ||
      document.querySelector('[data-testid="job-location"]')?.textContent ||
      "",
  );

  return {
    type: "job",
    title: title || "Imported role",
    company,
    url: window.location.href.split("#")[0],
    description,
    location: locationText || null,
  };
}

function fillLinkedInCompose(message) {
  const selectors = [
    'div.msg-form__contenteditable[contenteditable="true"]',
    'div[role="textbox"][contenteditable="true"]',
    "textarea",
  ];
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (!el) continue;
    el.focus();
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      el.value = message;
      el.dispatchEvent(new Event("input", { bubbles: true }));
    } else {
      el.innerHTML = `<p>${message.replace(/</g, "&lt;")}</p>`;
      el.dispatchEvent(new InputEvent("input", { bubbles: true }));
    }
    return { ok: true };
  }
  return {
    ok: false,
    error: "No compose box found. Open LinkedIn messaging or a connect note dialog first.",
  };
}

function detectAndExtract() {
  const path = window.location.pathname;
  if (path.includes("/messaging")) {
    return extractMessagingThread();
  }
  if (path.includes("/in/")) {
    return extractProfile();
  }
  if (path.includes("/jobs") || path.includes("/job/")) {
    return extractJobFromPage();
  }
  return extractPeople();
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "EXTRACT_PAGE") {
    try {
      sendResponse({ ok: true, data: detectAndExtract() });
    } catch (err) {
      sendResponse({ ok: false, error: err?.message || String(err) });
    }
    return true;
  }
  if (message?.type === "EXTRACT_JOB") {
    try {
      sendResponse({ ok: true, data: extractJobFromPage() });
    } catch (err) {
      sendResponse({ ok: false, error: err?.message || String(err) });
    }
    return true;
  }
  if (message?.type === "EXTRACT_THREAD") {
    try {
      sendResponse({ ok: true, data: extractMessagingThread() });
    } catch (err) {
      sendResponse({ ok: false, error: err?.message || String(err) });
    }
    return true;
  }
  if (message?.type === "FILL_COMPOSE") {
    sendResponse(fillLinkedInCompose(message.message || ""));
    return true;
  }
  return false;
});
