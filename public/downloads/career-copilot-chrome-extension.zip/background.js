const DEFAULT_API = "http://localhost:8000";

async function getSettings() {
  const stored = await chrome.storage.local.get(["apiUrl", "token", "appUrl"]);
  return {
    apiUrl: (stored.apiUrl || DEFAULT_API).replace(/\/$/, ""),
    token: stored.token || "",
    appUrl: (stored.appUrl || "http://localhost:5173").replace(/\/$/, ""),
  };
}

async function api(method, path, body) {
  const { apiUrl, token } = await getSettings();
  if (!token) {
    throw new Error("Set your Career Copilot API token in the extension popup.");
  }
  const response = await fetch(`${apiUrl}${path}`, {
    method,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  const text = await response.text();
  let payload = null;
  try {
    payload = text ? JSON.parse(text) : null;
  } catch {
    payload = { error: text };
  }
  if (!response.ok) {
    throw new Error(payload?.error || payload?.detail || `HTTP ${response.status}`);
  }
  return payload;
}

async function apiPost(path, body) {
  return api("POST", path, body);
}

async function apiGet(path) {
  return api("GET", path);
}

async function ensureContentScript(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "PING" });
  } catch {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content.js"],
    });
  }
}

async function messageActiveTab(message) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error("No active tab.");
  await ensureContentScript(tab.id);
  const response = await chrome.tabs.sendMessage(tab.id, message);
  if (!response?.ok && response?.error) {
    throw new Error(response.error);
  }
  return { tab, response };
}

async function extractFromActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error("No active tab.");
  if (!tab.url || !tab.url.includes("linkedin.com")) {
    throw new Error("Open a LinkedIn tab for this action.");
  }
  await ensureContentScript(tab.id);
  const response = await chrome.tabs.sendMessage(tab.id, { type: "EXTRACT_PAGE" });
  if (!response?.ok) {
    throw new Error(response?.error || "Could not read the LinkedIn page.");
  }
  return { tab, data: response.data };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    if (message?.type === "ANALYZE_PROFILE") {
      const { data } = await extractFromActiveTab();
      if (data.type !== "profile") {
        throw new Error("Navigate to your LinkedIn profile (/in/...) then try again.");
      }
      if ((data.profile_text || "").length < 80) {
        throw new Error("Not enough profile text. Expand About/Experience.");
      }
      const result = await apiPost("/linkedin/profile-analysis", {
        profile_text: data.profile_text,
        source: "extension",
      });
      return { ok: true, result, kind: "profile" };
    }

    if (message?.type === "IMPORT_PEOPLE") {
      const { data } = await extractFromActiveTab();
      if (data.type === "profile" || data.type === "thread") {
        throw new Error("Open a people search or company People page to import a list.");
      }
      if (data.type === "job") {
        throw new Error("This looks like a job page. Use Import job instead.");
      }
      if (!data.contacts?.length) {
        throw new Error("No people found. Scroll to load more results, then retry.");
      }
      const result = await apiPost("/linkedin/import-contacts", {
        contacts: data.contacts,
        company: data.company_guess || null,
        generate_drafts: false,
        source: "extension",
      });
      return { ok: true, result, kind: "people" };
    }

    if (message?.type === "IMPORT_JOB") {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id || !tab.url) throw new Error("No active tab.");
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"],
      });
      const response = await chrome.tabs.sendMessage(tab.id, { type: "EXTRACT_JOB" });
      if (!response?.ok) throw new Error(response?.error || "Could not extract job.");
      const job = response.data;
      const result = await apiPost("/networks/jobs/import", {
        title: job.title,
        company: job.company,
        url: job.url,
        description: job.description,
        location: job.location,
        source: "extension_import",
      });
      return { ok: true, result, kind: "job" };
    }

    if (message?.type === "SMART_NETWORK") {
      const company = message.company;
      if (!company) throw new Error("Company required");
      const result = await apiPost("/linkedin/find-network", {
        company,
        job_title: message.job_title || null,
      });
      return { ok: true, result, kind: "smart_network" };
    }

    if (message?.type === "AGENT_PROCESS") {
      const result = await apiPost("/networks/agent/process", {});
      return { ok: true, result, kind: "agent" };
    }

    if (message?.type === "AGENT_NEXT") {
      const queue = await apiGet("/networks/agent/queue");
      const next = queue.ready_to_send?.[0];
      if (!next) {
        await apiPost("/networks/agent/process", {});
        const again = await apiGet("/networks/agent/queue");
        const item = again.ready_to_send?.[0];
        if (!item) {
          return { ok: true, kind: "agent_empty", message: "No agent actions ready. Enroll contacts in the app." };
        }
        return openAndFill(item);
      }
      return openAndFill(next);
    }

    if (message?.type === "CONVERSATION_ASSIST") {
      const { data } = await extractFromActiveTab();
      let thread = data.type === "thread" ? data.thread_text : "";
      if (!thread || thread.length < 10) {
        const { response } = await messageActiveTab({ type: "EXTRACT_THREAD" });
        thread = response?.data?.thread_text || "";
      }
      if (!thread || thread.length < 10) {
        throw new Error("Open a LinkedIn conversation and ensure messages are visible.");
      }
      const result = await apiPost("/networks/conversation", {
        thread_text: thread,
        voice_notes: message.voice_notes || null,
      });
      const draft = result.drafts?.[0]?.body;
      if (draft) {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab?.id) {
          await chrome.tabs.sendMessage(tab.id, { type: "FILL_COMPOSE", message: draft });
        }
      }
      return { ok: true, result, kind: "conversation" };
    }

    if (message?.type === "HEALTH") {
      const result = await apiGet("/autopilot/health-summary");
      return { ok: true, result, kind: "health" };
    }

    return { ok: false, error: "Unknown action" };
  })()
    .then((payload) => sendResponse(payload))
    .catch((err) => sendResponse({ ok: false, error: err?.message || String(err) }));
  return true;
});

async function openAndFill(item) {
  const url = item.linkedin_url;
  const message = item.message || item.contact?.message_draft || "";
  const tab = await chrome.tabs.create({ url, active: true });
  // Give LinkedIn a moment to load, then try fill
  setTimeout(async () => {
    try {
      if (!tab.id) return;
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"],
      });
      await chrome.tabs.sendMessage(tab.id, { type: "FILL_COMPOSE", message });
    } catch {
      /* user can paste manually */
    }
  }, 3500);
  return {
    ok: true,
    kind: "agent_open",
    message: `Opened ${item.contact?.person_name || "contact"}. Paste/send the draft, then Mark sent in the app.`,
    draft: message,
    contact_id: item.contact?.id,
  };
}
