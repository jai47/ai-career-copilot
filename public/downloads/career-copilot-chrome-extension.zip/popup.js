const apiUrlEl = document.getElementById("apiUrl");
const appUrlEl = document.getElementById("appUrl");
const tokenEl = document.getElementById("token");
const companyEl = document.getElementById("company");
const statusEl = document.getElementById("status");

function setStatus(text, kind = "") {
  statusEl.textContent = text;
  statusEl.className = `status ${kind}`.trim();
}

async function load() {
  const stored = await chrome.storage.local.get(["apiUrl", "token", "appUrl"]);
  apiUrlEl.value = stored.apiUrl || "http://localhost:8000";
  appUrlEl.value = stored.appUrl || "http://localhost:5173";
  tokenEl.value = stored.token || "";
}

async function saveSettings() {
  await chrome.storage.local.set({
    apiUrl: apiUrlEl.value.trim().replace(/\/$/, ""),
    appUrl: appUrlEl.value.trim().replace(/\/$/, ""),
    token: tokenEl.value.trim(),
  });
}

document.getElementById("save").addEventListener("click", async () => {
  await saveSettings();
  setStatus("Settings saved.", "ok");
});

async function runAction(type, extra = {}) {
  setStatus("Working…");
  const buttons = document.querySelectorAll("button");
  buttons.forEach((b) => {
    b.disabled = true;
  });
  try {
    await saveSettings();
    const response = await chrome.runtime.sendMessage({ type, ...extra });
    if (!response?.ok) {
      throw new Error(response?.error || "Action failed");
    }
    if (response.kind === "profile") {
      setStatus(`Profile analyzed. Score: ${response.result?.overall_score ?? "?"}/100`, "ok");
    } else if (response.kind === "people") {
      setStatus(
        `Imported ${response.result?.created?.length ?? 0}; skipped ${response.result?.skipped ?? 0}`,
        "ok",
      );
    } else if (response.kind === "job") {
      setStatus(
        `Imported: ${response.result?.title} @ ${response.result?.company} (score ${response.result?.overall_score ?? "?"})`,
        "ok",
      );
    } else if (response.kind === "smart_network") {
      const lines = (response.result?.suggestions || [])
        .slice(0, 5)
        .map((s) => `• ${s.title_query}`)
        .join("\n");
      setStatus(`${response.result?.strategy_summary || ""}\n${lines}`, "ok");
    } else if (response.kind === "conversation") {
      const n = response.result?.drafts?.length ?? 0;
      setStatus(`Drafted ${n} reply(ies) and tried to fill the compose box.`, "ok");
    } else if (response.kind === "agent" || response.kind === "agent_open") {
      setStatus(response.message || `Ready: ${response.result?.ready_to_send?.length ?? 0}`, "ok");
    } else if (response.kind === "agent_empty") {
      setStatus(response.message, "ok");
    } else if (response.kind === "health") {
      const h = response.result;
      setStatus(
        `Apps ${h.applications_total} | Network ${h.network_contacts} | Agent ready ${h.agent_ready}\n` +
          `Resumes ${h.resume_versions} | Analytics ${h.analytics_unlocked ? "unlocked" : "locked"}\n` +
          `${h.tip}`,
        "ok",
      );
    } else {
      setStatus(JSON.stringify(response.result || response, null, 2).slice(0, 800), "ok");
    }
  } catch (err) {
    setStatus(err?.message || String(err), "error");
  } finally {
    buttons.forEach((b) => {
      b.disabled = false;
    });
  }
}

async function openApp(path) {
  await saveSettings();
  const appUrl = (appUrlEl.value || "http://localhost:5173").replace(/\/$/, "");
  await chrome.tabs.create({ url: `${appUrl}${path}` });
}

document.getElementById("importJob").addEventListener("click", () => runAction("IMPORT_JOB"));
document.getElementById("smartNetwork").addEventListener("click", () =>
  runAction("SMART_NETWORK", { company: companyEl.value.trim(), job_title: null }),
);
document.getElementById("importPeople").addEventListener("click", () => runAction("IMPORT_PEOPLE"));
document.getElementById("agentNext").addEventListener("click", () => runAction("AGENT_NEXT"));
document.getElementById("agentProcess").addEventListener("click", () => runAction("AGENT_PROCESS"));
document.getElementById("conversation").addEventListener("click", () => runAction("CONVERSATION_ASSIST"));
document.getElementById("analyze").addEventListener("click", () => runAction("ANALYZE_PROFILE"));
document.getElementById("health").addEventListener("click", () => runAction("HEALTH"));
document.getElementById("openResume").addEventListener("click", () => openApp("/resumes"));
document.getElementById("openInterview").addEventListener("click", () => openApp("/tracker"));
document.getElementById("openToday").addEventListener("click", () => openApp("/today"));

load();
